/**
 * 
 */
/**
 * 
 */
module PhoneBookProject {
	requires java.desktop;
}