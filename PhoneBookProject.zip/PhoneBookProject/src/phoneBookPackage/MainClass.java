package phoneBookPackage;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Scanner;


public class MainClass {

	private static Scanner userInput;
	private static PhoneBook phoneBook;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainClass.userInput = new Scanner(System.in);
		MainClass.phoneBook = new PhoneBook();
		boolean run = true;

		System.out.println("Welcome to Phone Book Interface");
		do {
			switch (MainClass.makeChoice()) {
			case 0:
				run = false;
				break;
			case 1:
				MainClass.cls();
				System.out.println();
				MainClass.addPerson();
				break;
			case 2:
				MainClass.cls();
				System.out.println();
				MainClass.findPerson();
				break;
			case 3:
				MainClass.cls();
				System.out.println();
				System.out.println(MainClass.phoneBook);
				break;
			case 4:
				MainClass.cls();
				System.out.println();
				MainClass.removePerson();

				break;
			case 5:
				MainClass.cls();
				System.out.println();
				MainClass.generateSaveFile();
				break;
			case 6:
				MainClass.cls();
				System.out.println();
				MainClass.loadFile();
				break;
			case 7:
				MainClass.cls();
				System.out.println();
				MainClass.generatePrintFile();
			}
			System.out.println();
		} while (run);
		System.out.println("Thank you for running");
		System.exit(1);

	}



	@SuppressWarnings("deprecation")
	public static void cls() {
		try {

			if (System.getProperty("os.name").contains("Windows"))
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			else
				Runtime.getRuntime().exec("clear");
		} catch (IOException | InterruptedException ex) {
		}
	}

	@SuppressWarnings("unused")
	public static int makeChoice() {
		do {
			System.out.println("Please select a choice:");
			System.out.println("\t0) Exit Program");
			System.out.println("\t1) Add a person");
			System.out.println("\t2) Find a person");
			System.out.println("\t3) View Phone Book");
			System.out.println("\t4) Remove a Person");
			System.out.println("\t5) Save File");
			System.out.println("\t6) Load File");
			System.out.println("\t7) Generate Print File");
			System.out.print("Your choice is: ");
			try {
				int choice = Integer.parseInt(MainClass.userInput.nextLine());
				switch (choice) {
				case 0:
				case 1:
				case 2:
				case 3:
				case 4:
				case 5:
				case 6:
				case 7:
					return choice;

				}
			} catch (Exception ex) {
			}
			System.out.println("Invalid choice try again. Press enter to continue.");
			String trash = MainClass.userInput.nextLine();

		} while (true);
	}


	


	public static void generatePrintFile() {
		String fileName;
		boolean run = true;
		StringBuilder sb = new StringBuilder();
		do {
			
			System.out.print("Enter name of file to print: ");
			fileName = MainClass.userInput.nextLine();
		
			if (fileName.indexOf(" ") != -1) {
				System.out.println("Invalid file name");
			} else {
				sb.append(fileName);
				sb.append(".txt");
				run = !MainClass.validString(sb.toString());
			}


		} while (run);
		fileName = sb.toString();
		try {
			FileWriter fw = new FileWriter(fileName,false);
			PrintWriter pw = new PrintWriter(fw);
			pw.print("Phone Book");
			pw.print(MainClass.phoneBook);
			pw.close();
			sb = new StringBuilder();
			sb.append(System.getProperty("user.dir"));
			sb.append("\\");
			sb.append(fileName);
			File file = new File(fileName);
			
			Desktop desktop = Desktop.getDesktop();
					
			if(file.exists()) {
				desktop.open(file);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void loadFile() {
		String fileName;
		do {
			StringBuilder sb = new StringBuilder();
			System.out.print("Enter saveFile name: ");
			fileName = MainClass.userInput.nextLine();
			sb.append(fileName);
			sb.append(".csv");
			fileName = sb.toString();
		} while (!MainClass.validString(fileName));
		try {
			File file = new File(fileName);
			Scanner readFile = new Scanner(file);
			readFile.useDelimiter(",");
			MainClass.phoneBook = new PhoneBook();
			while (readFile.hasNext()) {
				String line = readFile.nextLine();
				Scanner readLine = new Scanner(line);
				readLine.useDelimiter(",");
				String name = readLine.next();
				long phoneNumber = readLine.nextLong();
				readLine.close();
				MainClass.phoneBook.add(name, phoneNumber);
			}
			readFile.close();
			System.out.println("Successfully added");
			System.out.println();
			System.out.println(MainClass.phoneBook.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void generateSaveFile() {
		String personName;
		do {
			StringBuilder sb = new StringBuilder();
			System.out.print("Enter saveFile name: ");
			personName = MainClass.userInput.nextLine();
			sb.append(personName);
			sb.append(".csv");
			personName = sb.toString();
		} while (!MainClass.validString(personName));
		System.out.println();
		try {
			FileWriter fw = new FileWriter(personName, false);
			PrintWriter pw = new PrintWriter(fw);
			String fileInfo = MainClass.phoneBook.generateSaveFile();
			pw.print(fileInfo);
			pw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void addPerson() {
		String personName = null;
		long phoneNumber = 0;
		do {
			System.out.print("Enter person\'s name: ");
			personName = MainClass.userInput.nextLine();
		} while (!MainClass.validString(personName));
		System.out.println();
		do {
			phoneNumber = MainClass.enterPhoneNumber();

		} while (!MainClass.validNumber(phoneNumber));
		MainClass.phoneBook.add(personName, phoneNumber);

	}

	@SuppressWarnings("unused")
	private static boolean validString(String str) {
		do {
			if (str != null) {
				System.out.println("You have entered:");
				System.out.print("\t\"");
				System.out.print(str);
				System.out.println("\"\nIs this correct?");
				System.out.println("\t1) yes");
				System.out.println("\t2) no");
				System.out.print("Your choice is: ");
				try {
					int choice = Integer.parseInt(MainClass.userInput.nextLine());
					if (choice == 1)
						return true;
					else if (choice == 2)
						return false;

				} catch (Exception ex) {

				}
				System.out.println("Invalid choice try again. Press enter to continue.");
				String trash = MainClass.userInput.nextLine();
			} else {
				System.out.println("You entered null.");
				System.out.println("Invalid choice try again. Press enter to continue.");
				String trash = MainClass.userInput.nextLine();
				return false;
			}
		} while (true);
	}

	@SuppressWarnings("unused")
	private static long enterPhoneNumber() {
		do {
			System.out.print("Enter person\'s phone number: ");
			try {
				long phoneNumber = Long.parseLong(MainClass.userInput.nextLine());
				if (phoneNumber >= 0)
					return phoneNumber;
			} catch (Exception ex) {

			}
			System.out.println("Invalid entry try again. Press enter to continue.");
			String trash = MainClass.userInput.nextLine();
		} while (true);
	}

	@SuppressWarnings("unused")
	private static boolean validNumber(long phoneNumber) {
		do {
			System.out.println("You have entered: ");

			System.out.print("\t\"");
			System.out.print(MainClass.formatNumber(phoneNumber));
			System.out.println("\"\nIs this correct:");
			System.out.println("\t1) yes");
			System.out.println("\t2) no");
			System.out.println("Your choice is: ");
			try {
				int choice = Integer.parseInt(MainClass.userInput.nextLine());
				if (choice == 1)
					return true;
				else if (choice == 2)
					return false;
			} catch (Exception ex) {

			}
			System.out.println("Invalid choice try again. Press enter to continue.");
			String trash = MainClass.userInput.nextLine();

		} while (true);
	}

	public static String formatNumber(long phoneNumber) {
		DecimalFormat df = new DecimalFormat("0000000000");
		String phoneStr = df.format(phoneNumber);
		StringBuilder sb = new StringBuilder();
		sb.append("(");
		sb.append(phoneStr.substring(0, 3));
		sb.append(")");
		sb.append(" ");
		sb.append(phoneStr.substring(3, 6));
		sb.append("-");
		sb.append(phoneStr.substring(6, 10));
		return sb.toString();
	}

	public static void findPerson() {
		String name = null;
		do {
			System.out.print("Enter person\'s name: ");
			name = MainClass.userInput.nextLine();
		} while (!MainClass.validString(name));
		System.out.println();
		System.out.print(name);
		System.out.println("\'s info:");
		String info = MainClass.phoneBook.findPerson(name);

		if (info == null) {
			System.out.println("DNE");
		} else {
			System.out.println(info);
		}
	}

	public static void removePerson() {
		String name = null;
		do {
			System.out.print("Enter person\'s name: ");
			name = MainClass.userInput.nextLine();
		} while (!MainClass.validString(name));
		System.out.println();
		System.out.print(name);
		String info = MainClass.phoneBook.findPerson(name);
		if (info != null) {
			MainClass.phoneBook.remove(name);
		}

	}

}
