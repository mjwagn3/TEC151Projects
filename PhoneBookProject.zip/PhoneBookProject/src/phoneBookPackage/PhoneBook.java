package phoneBookPackage;

public class PhoneBook {

	private Person personRoot;

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Phone Book:\n");
		this.toString(sb, this.personRoot);
		return sb.toString();
	}

	private void toString(StringBuilder sb, Person personRoot) {
		if (personRoot != null) {
			this.toString(sb, personRoot.left);
			if (!personRoot.name.equals(" ")) {
				sb.append("\n");
				sb.append(personRoot);
				sb.append("\n");
			}
			this.toString(sb, personRoot.right);
		}

	}

	public String generateSaveFile() {
		StringBuilder sb = new StringBuilder();
		this.generateSaveFile(sb, this.personRoot);
		return sb.toString();
	}

	private void generateSaveFile(StringBuilder sb, Person personRoot) {
		if (personRoot != null) {
			this.generateSaveFile(sb, personRoot.left);
			if (!personRoot.name.equals(" ")) {
				sb.append(personRoot.name);
				sb.append(",");
				sb.append(personRoot.phoneNumber);
				sb.append(",\n");

			}
			this.generateSaveFile(sb, personRoot.right);
		}
	}

	public void add(String name, long phoneNumber) {
		if (this.personRoot == null) {
			this.personRoot = new Person(name, phoneNumber);
		} else {
			this.personRoot = this.add(this.personRoot, new Person(name, phoneNumber), 0);
		}
	}

	public String findPerson(String name) {
		return this.findPerson(this.personRoot, new Person(name), 0);
	}

	private String findPerson(Person personRoot, Person pass, int lvl) {
		if (personRoot == null)
			return null;
		if (personRoot.name.equals(pass.name)) {
			return personRoot.toString();
		} else {
			int compare = personRoot.compareTo(pass);
			if (compare == 0)
				return this.findPerson(personRoot.left, pass, lvl + 1);
			else if (compare == 1)
				return this.findPerson(personRoot.right, pass, lvl + 1);
			else
				return null;
		}
	}

	private Person add(Person personRoot, Person pass, int lvl) {
		if (personRoot == null) {
			personRoot = pass;
			return personRoot;
		} else {

			int compare = personRoot.compareTo(pass);
			if (compare == 0)
				personRoot.left = this.add(personRoot.left, pass, lvl + 1);
			else if (compare == 1)
				personRoot.right = this.add(personRoot.right, pass, lvl + 1);
			else {
				personRoot.phoneNumber = pass.phoneNumber;
			}
			return personRoot;
		}
	}

	

	public void remove(String name) {
		this.personRoot = this.remove(this.personRoot, name);
	}

	private Person remove(Person personRoot, String name) {
		if (personRoot == null)
			return personRoot;
		int compare = personRoot.compareTo(new Person(name, 0));
		if (compare == 0) {
			personRoot.left = this.remove(personRoot.left, name);
		} else if (compare == 1) {
			personRoot.right = this.remove(personRoot.right, name);
		} else {
			if(personRoot.left==null) {
				return personRoot.right;
			}
			if(personRoot.right==null) {
				return personRoot.left;
			}
			Person tempPerson = this.getSuccessor(personRoot);
			personRoot.name = tempPerson.name;
			personRoot.phoneNumber = tempPerson.phoneNumber;
			personRoot.right = this.remove(personRoot.right,tempPerson.name);
			
		}
		return personRoot;
	}
	private Person getSuccessor(Person personRoot) {
		personRoot = personRoot.right;
		while(personRoot!=null&&personRoot.left!=null) {
			personRoot = personRoot.left;
			
		}
		return personRoot;
	}

	private static class Person {
		private long phoneNumber;
		private String name;
		private Person left, right;

		public Person(String name, long phoneNumber2) {
			this.name = name;
			this.phoneNumber = (Math.abs(phoneNumber2));
		}

		public Person(String name) {
			this.name = name;
		}

		public int compareTo(Person p) {
			if (!p.name.equals(this.name)) {
				String test1 = this.name;
				String test2 = p.name;
				int i = 0;
				while (i < test1.length() && i < test2.length()) {
					if (test1.charAt(i) < test2.charAt(i)) {
						return 1;
					} else if (test1.charAt(i) > test2.charAt(i)) {
						return 0;
					}
					test1 = test1.substring(1);
					test2 = test2.substring(1);
				}
				if (test1.length() != 0) {
					return 1;
				} else {
					return 0;
				}
			}
			return -1;
		}

		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("Name:");
			sb.append("-------- ");
			sb.append(this.name);
			sb.append("\nPhone Number: ");
			sb.append(MainClass.formatNumber(this.phoneNumber));
			return sb.toString();

		}

	}
}
