﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
 * Name: Michael Wagner
 * Date: 1/24/24
 * Program/Assignment Name: Card Identifier (Chapter 2 program
 * problem 3)
 * 
 * Description: When the user clicks on a card, it will display
 * a text that idenifies the card. Then at the bottem of the prog
 * ram there will be an exit button
 * 
 * 
 * 
 */
namespace CardIdentifier
{
    public partial class CardIdentifier : Form
    {
        public CardIdentifier()
        {
            InitializeComponent();
        }

        private void CardIdentifier_Load(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This is a button to exit the program
            this.Close();
        }

        private void cardIdentifierLbl_Click(object sender, EventArgs e)
        {
            /*This is the Label where the text that will say where the
            * user will get info about card
            */

        }

        private void card1Button_Click(object sender, EventArgs e)
        {
            // This is the button that shows card 1 info
            cardIdentifierLbl.Text = "This is 1";

        }

        private void card2Button_Click(object sender, EventArgs e)
        {// This is the button that shows card 2 info
            cardIdentifierLbl.Text = "This is 2";


        }

        private void card3Button_Click(object sender, EventArgs e)
        {
            // This is the button that shows card 3 info
            cardIdentifierLbl.Text = "This is 3";

        }

        private void card4Button_Click(object sender, EventArgs e)
        {
            // This is the button that shows card 4 info
            cardIdentifierLbl.Text = "This is 4";

        }

        private void card5Button_Click(object sender, EventArgs e)
        {
            // This is the button that shows card 5 info
            cardIdentifierLbl.Text = "This is 5";

        }

        private void infoLbl_Click(object sender, EventArgs e)
        {
            // This is the label that tells the user what to do
        }
    }
}
