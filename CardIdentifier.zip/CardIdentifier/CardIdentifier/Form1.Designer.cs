﻿namespace CardIdentifier
{
    partial class CardIdentifier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.cardIdentifierLbl = new System.Windows.Forms.Label();
            this.card5Button = new System.Windows.Forms.Button();
            this.card4Button = new System.Windows.Forms.Button();
            this.card3Button = new System.Windows.Forms.Button();
            this.card2Button = new System.Windows.Forms.Button();
            this.card1Button = new System.Windows.Forms.Button();
            this.infoLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(177, 206);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // cardIdentifierLbl
            // 
            this.cardIdentifierLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cardIdentifierLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardIdentifierLbl.Location = new System.Drawing.Point(71, 180);
            this.cardIdentifierLbl.Name = "cardIdentifierLbl";
            this.cardIdentifierLbl.Size = new System.Drawing.Size(296, 23);
            this.cardIdentifierLbl.TabIndex = 1;
            this.cardIdentifierLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.cardIdentifierLbl.Click += new System.EventHandler(this.cardIdentifierLbl_Click);
            // 
            // card5Button
            // 
            this.card5Button.AutoSize = true;
            this.card5Button.Image = global::CardIdentifier.Properties.Resources.Five;
            this.card5Button.Location = new System.Drawing.Point(373, 27);
            this.card5Button.Name = "card5Button";
            this.card5Button.Size = new System.Drawing.Size(86, 150);
            this.card5Button.TabIndex = 6;
            this.card5Button.UseVisualStyleBackColor = true;
            this.card5Button.Click += new System.EventHandler(this.card5Button_Click);
            // 
            // card4Button
            // 
            this.card4Button.AutoSize = true;
            this.card4Button.Image = global::CardIdentifier.Properties.Resources.Four;
            this.card4Button.Location = new System.Drawing.Point(281, 27);
            this.card4Button.Name = "card4Button";
            this.card4Button.Size = new System.Drawing.Size(86, 150);
            this.card4Button.TabIndex = 5;
            this.card4Button.UseVisualStyleBackColor = true;
            this.card4Button.Click += new System.EventHandler(this.card4Button_Click);
            // 
            // card3Button
            // 
            this.card3Button.AutoSize = true;
            this.card3Button.Image = global::CardIdentifier.Properties.Resources.Three;
            this.card3Button.Location = new System.Drawing.Point(192, 27);
            this.card3Button.Name = "card3Button";
            this.card3Button.Size = new System.Drawing.Size(86, 150);
            this.card3Button.TabIndex = 4;
            this.card3Button.UseVisualStyleBackColor = true;
            this.card3Button.Click += new System.EventHandler(this.card3Button_Click);
            // 
            // card2Button
            // 
            this.card2Button.AutoSize = true;
            this.card2Button.Image = global::CardIdentifier.Properties.Resources.Two;
            this.card2Button.Location = new System.Drawing.Point(100, 27);
            this.card2Button.Name = "card2Button";
            this.card2Button.Size = new System.Drawing.Size(86, 150);
            this.card2Button.TabIndex = 3;
            this.card2Button.UseVisualStyleBackColor = true;
            this.card2Button.Click += new System.EventHandler(this.card2Button_Click);
            // 
            // card1Button
            // 
            this.card1Button.AutoSize = true;
            this.card1Button.Image = global::CardIdentifier.Properties.Resources.One;
            this.card1Button.Location = new System.Drawing.Point(8, 27);
            this.card1Button.Name = "card1Button";
            this.card1Button.Size = new System.Drawing.Size(86, 150);
            this.card1Button.TabIndex = 2;
            this.card1Button.UseVisualStyleBackColor = true;
            this.card1Button.Click += new System.EventHandler(this.card1Button_Click);
            // 
            // infoLbl
            // 
            this.infoLbl.AutoSize = true;
            this.infoLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infoLbl.Location = new System.Drawing.Point(133, 9);
            this.infoLbl.Name = "infoLbl";
            this.infoLbl.Size = new System.Drawing.Size(199, 18);
            this.infoLbl.TabIndex = 7;
            this.infoLbl.Text = "Click a Card to See Its Name";
            this.infoLbl.Click += new System.EventHandler(this.infoLbl_Click);
            // 
            // CardIdentifier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 242);
            this.Controls.Add(this.infoLbl);
            this.Controls.Add(this.card5Button);
            this.Controls.Add(this.card4Button);
            this.Controls.Add(this.card3Button);
            this.Controls.Add(this.card2Button);
            this.Controls.Add(this.card1Button);
            this.Controls.Add(this.cardIdentifierLbl);
            this.Controls.Add(this.exitButton);
            this.Name = "CardIdentifier";
            this.Text = "Card Identifier";
            this.Load += new System.EventHandler(this.CardIdentifier_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label cardIdentifierLbl;
        private System.Windows.Forms.Button card1Button;
        private System.Windows.Forms.Button card2Button;
        private System.Windows.Forms.Button card3Button;
        private System.Windows.Forms.Button card4Button;
        private System.Windows.Forms.Button card5Button;
        private System.Windows.Forms.Label infoLbl;
    }
}

